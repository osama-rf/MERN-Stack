const mongoose = require('mongoose')

const PirateSchema = new mongoose.Schema({
    name:{
        type:String,
        required:[true, "Name of the pirate is required!"]
    },
    numberChests:{
        type:Number,
        required: [true, "Number of treasure chests is required!"]
    },
    position: {
        type:String,
        required: [true, "You Must provide position of the pirate"]
    },
    catchPhrase: {
        type:String,
        required: [true, "You must provided catchphrase of the pirate"]
    },
    image: {
        type:String,
        required: [true, "You must provided Url of the pirate"]
    },
    pegLeg: {
        type:Boolean,
        required: [true, "Pirate have peg leg?"]
    },
    eyePatch: {
        type:Boolean,
        required: [true, "Pirate have eye patch?"]
    },
    hookHand: {
        type: Boolean,
        required: [true, "Pirate have hook hand?"]
    }
})

const Pirate = mongoose.model("Pirate", PirateSchema)

module.exports = Pirate;