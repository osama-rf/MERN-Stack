class Knight {
    constructor(name, clan, hp, str, force, power, block) {
        this.name = name;
        this.clan = clan;
        this.hp = hp;
        this.str = str;
        this.force = force;
        this.power = power;
        this.block = block;
    }

    lightsaberAttack(target){
        if (Math.ceil(Math.random() * 10 + this.str) < target.block){
            this.force -= 5
            target.hp += 1
            console.log(`${target.name} block the light-saber attack of ${this.name}, stats now ${target.name} has health ${target.hp}, force ${target.force} remaining. and ${this.name} has ${this.hp}, ${this.force} remaining!`)
        } else {
            target.hp -= 5
            target.force -= 2
            console.log(`${this.name} make damage to the to ${target.name}, stats now ${target.name} has health ${target.hp}, force ${target.force} remaining. and ${this.name} has ${this.hp}, ${this.force} remaining!`)
        }
    }

    forceAttack(target){
        if (Math.ceil(Math.random()* 30 + this.str) < target.block){
            this.force -= 5
            target -= 5
            console.log(`${target.name} block the force attack of ${this.name}, stats now ${target.name} has health ${target.hp}, force ${target.force} remaining. and ${this.name} has ${this.hp}, ${this.force} remaining!`)
        } else {
            target.hp -= 10
            target.force -= 5
            this.hp += 5
            this.force += 5
            console.log(`${this.name} use the force to attack the ${target.name} and he make a huge damage to his health and force, stats now ${target.name} has health ${target.hp}, force ${target.force} remaining. and ${this.name} has ${this.hp}, ${this.force} remaining!`)
        }
    }

    highGroundAttack(target) {
        if (Math.ceil(Math.random()* 50 + this.str) < target.block){
            this.hp -= 40
            this.force -= 15
            target.force -= 10
            console.log(`${target.name} has blocked an fetal attack from the ${this.name}, stats now ${target.name} has health ${target.hp}, force ${target.force} remaining. and ${this.name} has ${this.hp}, ${this.force} remaining!`)
        } else {
            target.hp -= 30
            target.force -= 10
            this.hp += 10
            this.force += 10
            console.log(`${target.name} receive a fetal attack from the ${this.name}, stats now ${target.name} has health ${target.hp}, force ${target.force} remaining. and ${this.name} has ${this.hp}, ${this.force} remaining!`)
        }
    }
}


class Jedi extends Knight{

    constructor(name) {
        super(name, "Jedi", "100", "100", "100", "100", "50");
    }
}

class Sith extends Knight{

    constructor(name) {
        super(name, "Sith", "100", "100", "100", "100", "50");
    }
}



